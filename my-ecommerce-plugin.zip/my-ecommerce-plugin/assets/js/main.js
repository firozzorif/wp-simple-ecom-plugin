jQuery(document).ready(function($){
    console.log("E-commerce plugin loaded");
});
