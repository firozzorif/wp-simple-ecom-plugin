<h2>Checkout</h2>
<form method="post">
    <p><input type="text" name="name" placeholder="Your Name" required></p>
    <p><input type="email" name="email" placeholder="Your Email" required></p>
    <button type="submit" style="padding:10px; background:#0073aa; color:#fff;">Place Order</button>
</form>
